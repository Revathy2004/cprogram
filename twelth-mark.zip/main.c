/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int tam=99;
    int eng=99;
    int mat=90;
    int bio=80;
    int phy=85;
    int che=85;
    int tot=538;
    float per=89.6;
    printf("mark in tamil=%d\n",tam);
    printf("mark in English=%d\n",eng);
    printf("mark in maths=%d\n",mat);
    printf("mark in Biology=%d\n",bio);
    printf("mark in Physics=%d\n",phy);
    printf("mark in che=%d\n",che);
    printf("totalmark=%d\n",tot);
    printf("percentage=%f\n",per);


    return 0;
}
