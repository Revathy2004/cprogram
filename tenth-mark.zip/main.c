/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int tam=99;
    int eng=99;
    int mat=90;
    int sci=80;
    int soc=85;
    int tot=453;
    float per=90.6;
    printf("mark in tamil=%d\n",tam);
    printf("mark in English=%d\n",eng);
    printf("mark in maths=%d\n",mat);
    printf("mark in science=%d\n",sci);
    printf("mark in social=%d\n",soc);
    printf("totalmark=%d\n",tot);
    printf("percentage=%f\n",per);


    
    return 0;
}
