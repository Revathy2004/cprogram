/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int fs = 15000;
int twd = 30;
int pd = 26;
int odsal = fs/twd;
int ts = pd*odsal;
float inc = fs*5/100;
int netsal = ts+inc;
printf("fixed salary is %d\n",fs);
printf("Total days of work is %d\n",twd);
printf("present days is %d\n",pd);
printf("one day salary is %d\n",odsal);
printf("total salaryis %d\n",ts);
printf("Income is %f\n",inc);
printf("Net salary is %d\n",netsal);

return(0);



    
}
